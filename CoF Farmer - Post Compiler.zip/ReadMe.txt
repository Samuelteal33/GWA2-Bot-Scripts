How to use this program :
    - Start Guild Wars
    - Log onto your dervish
    - Equip a scythe
    - Run the bot
    - If one instance of Guild Wars is open Then
        - Click Start
    - Else if multiple instances of Guild Wars are open Then
        - Select the character you want from the dropdown menu
        - Click Start

Preparations:
    - Dervish Equipment: 
        - Windwalker or Blessed Insignia
        - +4 Windprayers, 
        - +1 Scythe Mastery
        - +1 Mystisicm
        - +50 HP Rune
        - +2 Energy Rune
    - Dervish Weapon: 
        - Equip a Zealous Scythe of Enchanting with a random inscription.
    - Skillbar Template: 
        - OgCjkqqLrSihdftXYijhOXhX0kA
    - If You have no IAU: 
        - It is no problem (Bot will still work, the failrate will just increase slightly).
    - Remember to get the Quest Temple of the Damned