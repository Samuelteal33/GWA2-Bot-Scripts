#################################
#	Vaettir Bot by Blake v2.2	#
#################################

Character Equipment:
		Build:		OwVUI2h5lPP8Id2BkAiAvpLBTAA
		Insignia:	5x Blessed
		Headpiece:	+1 Shadow Arts
		Runes:		+3 Shadow Arts, Superior Vigor, 3x Rune of Attunement
		Weapons:
			1. Sword/Axe/Spear of Enchanting (Inscription: +5 Energy)
			2. Shield: +45^ench, +10 vs Earth
	
	
	If available the Bot will use speed boost in the outpost and Cupcake for the run to Jaga.
	The Bot will pick up all Event Items.
	If the Checkbox is ticked, it will pick up all weapons and salvage them for materials.
	
	Make sure there is enough space in the chest!
	I would advice you to upgrade your inventory to 60 slots, so the Bot can stay longer at Jaga.
	If you only have 45 inventory slots, you probably have to reduce the numbers for $NumberOfIdentKits and $NumberOfSalvageKits.
	

*** Default Settings ***

1.You can choose, if you want to pick up and salvage all weapons.
By default this option is turned on.
You can change this Setting also during the Runtime of the Bot by using the Checkbox!

If you want to change the default setting do this:

1. Open "vaettir.au3" with a text editor
2. Search (Ctrl+F) for "Func SetCheckboxes"
3. Change	"GUICtrlSetState($SalvageBox, $GUI_CHECKED)" TO
			"GUICtrlSetState($SalvageBox, $GUI_UNCHECKED)"

*** Default Settings ***


*** Warning about Storage Slots ***

I have not tested what happens if you run out of storage slots.
Make sure to adjust how many Ident and Salvage Kits the Bot buys, depending on your Inventory Size.

*** Warning about Storage Slots ***


*** Automatic Start and Restart Function ***

If you use the automatic start function the Bot will do everything for you.
If you don't want to use it you don't have to! Just use the Bot as normal.

1. Bot will start Guild Wars and log in.
2. Bot will go to the right Character.
3. Bot will start farming.
4. If the game crashes, the bot will restart Guild Wars, log in and start farming again.

*If you want to use this feature you will have to fill out your Account information in FeatherAccounts.au3!*
The information is stored in the Accounts[][] array. I have prepared a template for up to 8 Accounts.
The last parameter of the Accounts[][] array is a Boolean(True/False), only turn this parameter to "True"
for the Accounts you want to run, leave the rest "False".

Fill out the needed information: 

1. Open "VaettirAccounts.au3" with a text editor
2. Each line of Accounts[][] array represents one Account
3. Fill out Email, Character Name, Password, absolute path to gw.exe
4. leave the rest
5. Turn last parameter from False to True

6. Fill out the variable $AutoITEXE with the absolute path to autoit3.exe
7. Fill out the variable $ScriptAU3 with the absolute path to featherbot.au3
8. Fill out the variable $MultiLaunchEXE with the absolute path GWMultiLaunch.exe (it's in the same folder with the bot)
	(Maybe you will need some .NET Windows libraries. Before starting Bot, try starting GWMultiLaunch.exe with doubleclick)
9. Start running the Bots by doublelick on "LaunchBots.au3" !!!

*** Automatic Start and Restart Function ***